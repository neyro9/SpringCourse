package pl.example.workshopspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkshopspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkshopspringApplication.class, args);
	}

}
